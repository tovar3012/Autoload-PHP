
<?php 

	require_once('autoload.php');

	use App\Controller\User;

	$u = new User();

	echo $u->crear();

?>