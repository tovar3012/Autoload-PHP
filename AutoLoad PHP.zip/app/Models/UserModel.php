<?php 
	namespace App\Models;

	class UserModel{
		public static function crearUser(){
			return "Usuario creado!";
		}
	}

?>