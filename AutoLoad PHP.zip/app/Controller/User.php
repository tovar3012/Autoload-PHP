<?php 
	namespace App\Controller;
	
	use App\Models\UserModel;

	class User{

		public function crear(){
			return UserModel::crearUser();
		}

	}


?>